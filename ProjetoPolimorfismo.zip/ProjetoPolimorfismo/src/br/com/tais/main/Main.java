package br.com.tais.main;

import br.com.tais.animal.Cachorro;
import br.com.tais.animal.Gato;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gato objGato = new Gato("Garfild",9);
		objGato.emitirSom();
		
		Cachorro objCao = new Cachorro("luck",12);
		objCao.emitirSom();
		
		objCao.setIdade(19);
		System.out.println(objCao.getIdade());
		
	}

}
