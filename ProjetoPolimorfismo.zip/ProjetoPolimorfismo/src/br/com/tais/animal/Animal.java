package br.com.tais.animal;

//Declaração dos atributos(caracteristicas da classe)
public class Animal {
	private String nome;
	private int idade;
	// inicialização do construtor da classe (source/ criat constructer using fildes)
	public Animal(String nome, int idade) {
		super();
		this.nome = nome;
		this.idade = idade;
	}
	// metados(ações) da classe
	public void emitirSom() {
		System.out.println("Animal emitindo som...");
	}
	public int getIdade() { // pega o valor (get)
		return idade;
	}
	public void setIdade(int idade) { // altera o valor (set)
		if (idade <= 100) {
			this.idade = idade;
		}else {
			System.out.println("Não existe animal com esta idade");
		}
		
	}
	
	// permitir que uma classe de fora faça aletrações no privado(sousce/gerar get insert)
}
