package br.com.tais.animal;
// usa o extends para chamar as funções da classe pai
public class Gato extends Animal {

	public Gato(String nome, int idade) {
		super(nome, idade);
		// TODO Auto-generated constructor stub
	}
	// polimorfismo ( source/override/implement metados)

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		super.emitirSom();
		System.out.println("Miauuuu");
	}
	

}
