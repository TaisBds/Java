package br.com.tais.animal;

public class Cachorro extends Animal{

	public Cachorro(String nome, int idade) {
		super(nome, idade);
		// TODO Auto-generated constructor stub
		
	}

	@Override
	public void emitirSom() {
		// TODO Auto-generated method stub
		super.emitirSom();
		System.out.println("AuAu");
	}

}
