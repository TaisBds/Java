package br.com.academia.imc;


public class Atleta extends Pessoa {
	private String EsportePraticado;
	public int QtdMedalhas;
	
	
public void EsportePraticado() {
	System.out.println("Esporte Praticado pelo Atleta");
}

public void QtdMedalhas() {
	System.out.println("Quatidade de medalhas conquistadas:");}


public Atleta(String nome, double peso, double altura,String EsportePraticado,int qtdMedalhas) {
	super(nome, peso, altura);
	this.EsportePraticado = EsportePraticado;
	QtdMedalhas = qtdMedalhas;
}

@Override
public double CalcularImc(double altura, double peso) {
	// TODO Auto-generated method stub
	return super.CalcularImc(altura, peso)*0.05;
}

public String getEsportePraticado() {
	return EsportePraticado;
}

public void setEsportePraticado(String esportePraticado) {
	EsportePraticado = esportePraticado;
}

public int getQtdMedalhas() {
	return QtdMedalhas;
}

public void setQtdMedalhas(int qtdMedalhas) {
	QtdMedalhas = qtdMedalhas;
}



}
