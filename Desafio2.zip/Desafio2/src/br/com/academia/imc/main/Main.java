package br.com.academia.imc.main;

import br.com.academia.imc.Atleta;
import br.com.academia.imc.Pessoa;

public class Main {
	public static void main(String[] args) {

		
		Pessoa objPessoa = new Pessoa( "Anna", 71.8, 1.80);
			double resultadoImc =	objPessoa.CalcularImc(71.8, 1.80);
			System.out.println(resultadoImc);
			objPessoa.EscolherExercicio();
			objPessoa.EscolherHora();
			
			
		Atleta objAtleta = new Atleta("João", 89.90, 1.90, "Natação",4);
		System.out.println(objAtleta.CalcularImc(89.90,1.90));
		objAtleta.EsportePraticado();
		objAtleta.QtdMedalhas();
		
				
	}	
		}
