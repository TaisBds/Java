/**
 * 
 */
/**
 * 
 */
module Desafio1Interface {
}