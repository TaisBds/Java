package br.com.tais.interfaces;

public interface ITransporte {
	public void mover();
	
	
}
