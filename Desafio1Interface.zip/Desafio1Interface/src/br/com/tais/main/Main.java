package br.com.tais.main;

import br.com.tais.classes.Bicicleta;
import br.com.tais.classes.Carro;
import br.com.tais.classes.Onibus;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Carro objCarro = new Carro();
		objCarro.mover();
		System.out.println("O carro está se movendo pelas estradas");
		
		
		Bicicleta objBicicleta = new Bicicleta();
		objBicicleta.mover();
		System.out.println("A bicicleta está sendo pedalada");
		
		Onibus objOnibus = new Onibus();
		objOnibus.mover();
		System.out.println("O Onibus está se movendo pela rota urbana");
		
		
	}

}
