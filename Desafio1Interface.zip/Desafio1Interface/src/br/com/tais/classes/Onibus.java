package br.com.tais.classes;

import br.com.tais.interfaces.ITransporte;

public class Onibus implements ITransporte{

	@Override
	public void mover() {
		// TODO Auto-generated method stub
		
	}

}
