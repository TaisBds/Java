package br.com.tais.classes;

import br.com.tais.interfaces.ITransporte;

public class Carro implements ITransporte {

	@Override
	public void mover() {
		// TODO Auto-generated method stub
		
	}

}
