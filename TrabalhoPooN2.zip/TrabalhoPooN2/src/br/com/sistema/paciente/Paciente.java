package br.com.sistema.paciente;

public class Paciente {

    // Atributos
    private String nome;
    private String cpf;
    private String telefone;

    // Método
    public void esperarAtendimento() {
        System.out.println("Paciente: "+nome + " esperando atendimento.");
    }

    // Construtor (obriga os atributos a serem inicializados)
    public Paciente(String nome, String cpf, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    // Getters e Setters (sem setCpf para não permitir alteração do CPF)

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
