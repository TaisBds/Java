package br.com.sistema.agendamento;

import br.com.sistema.interfaces.IaAgendavel;

public class Consulta implements IaAgendavel {

    private String data;
    private String hora;

    public Consulta(String data, String hora) {
        this.data = data;
        this.hora = hora;
    }

    // Método da interface
    @Override
    public void agendarConsulta() {
        System.out.println("Consulta agendada para data " + data + " às " + hora + ".");
    }

    // Getters e Setters
    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
}
