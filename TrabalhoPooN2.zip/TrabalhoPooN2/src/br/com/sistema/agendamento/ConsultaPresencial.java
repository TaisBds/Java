package br.com.sistema.agendamento;

public class ConsultaPresencial extends Consulta {

    private int Consultorio;
    
    // Construtor 
    public ConsultaPresencial(String data, String hora,int Consultorio) {
        super(data, hora); 
        this.Consultorio = Consultorio;
    }
    
    // Método
    public void ConsultorioMedico() {
        if (Consultorio > 10) {
            System.out.println("Consultório inexistente. Falha no agendamento da consulta.");
        } else {
            System.out.println("Consulta presencial no consultório número " + Consultorio + ".");
        }
    }
    
    // Override do método da interface
    @Override
    public void agendarConsulta() {
        super.agendarConsulta();
        System.out.println("Consulta Presencial agendada para data " + getData() + " às " + getHora() + ".");
    }

    // Getter e Setter
    public int getLocal() {
        return Consultorio;
    }

    public void setLocal(int Consultorio) {
        this.Consultorio = Consultorio;
    }
}
