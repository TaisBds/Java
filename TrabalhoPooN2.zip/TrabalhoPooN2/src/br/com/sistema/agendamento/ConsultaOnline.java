package br.com.sistema.agendamento;

public class ConsultaOnline extends Consulta {

    private String linkVideoChamada;
    
    // Construtor
    public ConsultaOnline(String data, String hora, String linkVideoChamada) {
        super(data, hora);
        this.linkVideoChamada = linkVideoChamada;
    }
    
    // Método específico
    public void enviarLink() {
        System.out.println("Link para a consulta online: " + linkVideoChamada);
    }
    
    // Override do método da interface
    @Override
    public void agendarConsulta() {
        super.agendarConsulta();
        System.out.println("Consulta online agendada para data " + getData() + " às " + getHora() + ".");
    }
    
    // Getter e Setter
    public String getLinkVideoChamada() {
        return linkVideoChamada;
    }
    
    public void setLinkVideoChamada(String linkVideoChamada) {
        this.linkVideoChamada = linkVideoChamada;
    }
}
