package br.com.sistema.main;

import br.com.sistema.paciente.Paciente;
import br.com.sistema.medico.Medico;
import br.com.sistema.agendamento.Consulta;
import br.com.sistema.agendamento.ConsultaOnline;
import br.com.sistema.agendamento.ConsultaPresencial;

public class Main {
    public static void main(String[] args) {

      
    	try {
    		
    	
    	// Criando um paciente
        Paciente objpaciente = new Paciente("Ana Silva", "123.456.789-00", "(61) 91234-5678");
        objpaciente.esperarAtendimento(); 
        
        // Criando um médico
        Medico objmedico = new Medico("Dr. João", "Cardiologia");
        objmedico.atenderPacientes();
        
        System.out.println("......................................................");
        
        //Criando uma Consulta
        Consulta objconsulta = new Consulta("14/06/2026","19:00");
        objconsulta.agendarConsulta();
        
        System.out.println("......................................................");
        
        // Criando uma consulta presencial
        ConsultaPresencial objconsultaPresencial = new ConsultaPresencial("15/06/2025", "14:30", 12);
        objconsultaPresencial.agendarConsulta(); 
        objconsultaPresencial.ConsultorioMedico(); 
        
        System.out.println("......................................................");

        // Criando uma consulta online
        ConsultaOnline objconsultaOnline = new ConsultaOnline("16/06/2025", "10:00", "https://meet.link/consulta123");
        objconsultaOnline.agendarConsulta();
        objconsultaOnline.enviarLink(); 
        
        System.out.println("......................................................");
    } catch(Exception e) {
    	System.out.println("ocorreu um erro durante a execução do sistema : "+e);
    	
    }  	
    }
}
