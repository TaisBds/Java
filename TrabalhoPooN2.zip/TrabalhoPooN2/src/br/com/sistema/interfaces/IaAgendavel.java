package br.com.sistema.interfaces;

public interface IaAgendavel {
    void agendarConsulta();  
}
// interface , contrato para agendamento de consultas 