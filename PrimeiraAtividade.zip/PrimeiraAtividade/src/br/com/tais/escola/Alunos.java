package br.com.tais.escola;

public class Alunos {
	
public String nome;
private String matricula;

public void Aprender() {
	System.out.println("Aluno Aprende na Escola");
}
public void Locomover() {
	System.out.println("Aluno se locomove até a Escola");
}
}
