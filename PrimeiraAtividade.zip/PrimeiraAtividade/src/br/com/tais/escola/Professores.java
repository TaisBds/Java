package br.com.tais.escola;

public class Professores {

	public String Nome;
	public String Especializacao;
	private String Genero;
	
	public void generopro(boolean mulher) {
		if(mulher==true) {
			System.out.println("Genero Feminino");
			
		}else {
			System.out.println("Genero Masculino");
		}
		
}
		public void Especializacao() {
			System.out.println("Especialização do Professor");
}
		
				
}
