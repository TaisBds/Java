package br.com.tais.escola;

public class Disciplinas {
	
	public String nome;
	public String calAcademico;
	public String Professor;
	
	public void TransmitirEnsinamento() {
		System.out.println("Disciplina transmite ensinamento para Alunos");
	}
	public void SeguirCalAcademico() {
		System.out.println("Escola Acompanha o  caléndario Acâdemico");
	}
}
