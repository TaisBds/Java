package br.com.tais.main;

import br.com.tais.academia.Aulas;
import br.com.tais.academia.Equipamentos;
import br.com.tais.academia.Instrutores;
import br.com.tais.escola.Alunos;
import br.com.tais.escola.Disciplinas;
import br.com.tais.escola.Professores;

public class Main {

	public static void main(String[] args) {
		
		//instanciando objetos de Academia:
		
		Aulas objAulas = new Aulas();
		Equipamentos objEquipamentos = new Equipamentos();
		Instrutores objInstrutores = new Instrutores();
		
		System.out.println("Objetos Acadêmia: ");
		objAulas.EscolherHorarios();
		objAulas.EscolherInstrutor();
		
		objEquipamentos.cor();
		objEquipamentos.DefenirNumMaq();
		objEquipamentos.Definirpeso();
		
		objInstrutores.DefinirEspecializacao();
		objInstrutores.genero(false);
		
		//instanciando objetos de Escola:
		
		Alunos objAlunos = new Alunos();
		Disciplinas objDisciplinas = new Disciplinas();
		Professores objProfessores = new Professores();
		
		System.out.println("Objetos Escola:");
		objAlunos.Aprender();
		objAlunos.Locomover();
		
		objDisciplinas.SeguirCalAcademico();
		objDisciplinas.TransmitirEnsinamento();
		
		objProfessores.Especializacao();
		objProfessores.generopro(true);
		

	}

}
