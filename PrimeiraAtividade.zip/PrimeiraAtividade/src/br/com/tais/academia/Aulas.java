package br.com.tais.academia;

public class Aulas {
	
	public String TipoAula;
	public String Instrutor;
	public int Qtdrepetições;
	private double Horarios;
	
	private void  EscolherAula() {
		System.out.println("Escolher tipo de aula a ser realizada");
	}
	public void EscolherInstrutor() {
		System.out.println("Escolher Profissional");
		
	}
	public void Repetições() {
		System.out.println(" Defenir quantidade de repetições ");
	}
	public void EscolherHorarios() {
		System.out.println("Escolher Hórarios de Aulas");
	}
}
