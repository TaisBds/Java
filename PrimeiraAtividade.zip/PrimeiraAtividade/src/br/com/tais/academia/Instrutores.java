package br.com.tais.academia;

public class Instrutores {
	
	public String Nome;
	private String Genero;
	public String Especializacao;
	private int Idade;
	
	
	public void Nome() {
		System.out.println(" nome do instrutor");
	}
	
	public void genero(boolean mulher) {
		if(mulher==true) {
			System.out.println("Genero Feminino");
			
		}else {
			System.out.println("Genero Masculino");
		}
	}
		
		public void DefinirEspecializacao() {
			System.out.println("Especialização do instrutor");
		}
		public void idade() {
			System.out.println("Idade do instrutor");
		}
	}


