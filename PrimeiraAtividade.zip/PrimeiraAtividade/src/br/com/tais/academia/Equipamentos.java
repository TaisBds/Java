package br.com.tais.academia;

public class Equipamentos {

	public int peso;
	public double tamanho;
	public double velocidade;
	public String cor;
	public int NumMaq;
	
	public void Definirpeso() {
		System.out.println("Definir Peso do alter");
	}
	public void tamanho() {
		System.out.println("Tamanho do Aparelo");
	}
	public void cor() {
		System.out.println("Coloração do Aparelho");
		
	}
	public void DefenirNumMaq() {
		System.out.println("Numero da Maquina para o exercicio");
	}
	
	
}
