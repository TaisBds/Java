package PetshopMain;

import Petshop.Cachorro;
import Petshop.Gato;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cachorro objCachorro= new Cachorro("Latido Agudo");
		objCachorro.banho();
		objCachorro.tosa();
		objCachorro.ConsultaVeterinaria();
	
		Gato objGato = new Gato(7);
		objGato.banho();
		objGato.ConsultaVeterinaria();
		objGato.tosa();
		objGato.getFlexibilidade();
		System.out.println(objGato.getFlexibilidade());
		objGato.setFlexibilidade(8, 18);
		System.out.println(objGato.getFlexibilidade());
	}
	

}
