package Petshop;

public class Gato extends Animal {
 
	private int flexibilidade;

	public Gato(int flexibilidade) {
		super();
		this.flexibilidade = flexibilidade;
	}
	public int getFlexibilidade() {
		return flexibilidade;
	}

	public void setFlexibilidade(int flexibilidade,int idade) {
		this.flexibilidade = flexibilidade;
		if(idade>10){
			this.flexibilidade = flexibilidade;
			
		}else {
			System.out.println("Gato ainda jovem , nao pode mudar a flexibilidade");
		}
	}

	@Override
	public void banho() {
		// TODO Auto-generated method stub
		super.banho();
		System.out.println("Banho R$ 70,00");
	}

	@Override
	public void tosa() {
		// TODO Auto-generated method stub
		super.tosa();
		System.out.println("Banho R$ 60,00");
	}

	@Override
	public void ConsultaVeterinaria() {
		// TODO Auto-generated method stub
		super.ConsultaVeterinaria();
		System.out.println("Banho R$ 120,00");
	}
	
 
 
}
