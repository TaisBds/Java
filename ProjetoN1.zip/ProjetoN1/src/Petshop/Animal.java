package Petshop;

public class Animal {
	public void banho() {
		System.out.println("Banho");
	}
	public void tosa() {
		System.out.println("Tosa");
	}
	public void ConsultaVeterinaria() {
		System.out.println("Valor Consulta");
	}
}
