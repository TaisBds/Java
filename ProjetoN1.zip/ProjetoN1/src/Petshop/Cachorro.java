package Petshop;

public class  Cachorro extends Animal {
	private String latido;
	
	public Cachorro(String latido) {
		super();
		this.latido=latido;
		
	}
	public String getlatido() {
		return latido;
	}
	public void setlatido(String latido) {
		this.latido=latido;
	}
	@Override
	public void banho() {
		// TODO Auto-generated method stub
		super.banho();
		System.out.println("Banho cachorro: R$ 45,00");
	}
	@Override
	public void tosa() {
		// TODO Auto-generated method stub
		super.tosa();
		System.out.println("Tosa cachorro: R$ 45,00");
	}
	
	@Override
	public void ConsultaVeterinaria() {
		// TODO Auto-generated method stub
		super.ConsultaVeterinaria();
		System.out.println("Consulta Veterinaria cachorro: R$ 145,00");
	}
	public void exibirinformacao() {
		System.out.println("Informações"+latido);
	}
}
	


