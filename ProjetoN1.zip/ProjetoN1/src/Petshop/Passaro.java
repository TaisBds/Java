package Petshop;

public class Passaro {

}
