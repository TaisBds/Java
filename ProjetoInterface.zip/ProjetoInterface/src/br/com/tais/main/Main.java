package br.com.tais.main;

import br.com.tais.interfaces.Calculadora;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculadora objCalculadora = new Calculadora();
		
		System.out.println("Valor da soma n1 + n2 : "+objCalculadora.somar(7, 3));
		
		System.out.println("Valor da soma n1 + n2 + n3 é : "+objCalculadora.somar(2, 7, 6));
		
		

	}

}
