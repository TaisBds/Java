package br.com.tais.interfaces;

public interface ICalculadora {
	public int somar(int n1, int n2);
	public int somar(int n1,  int n2, int n3);

}
