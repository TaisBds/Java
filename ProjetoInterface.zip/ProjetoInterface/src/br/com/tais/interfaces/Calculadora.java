package br.com.tais.interfaces;

public class Calculadora implements ICalculadora {

	@Override
	public int somar(int n1, int n2) {
		// TODO Auto-generated method stub
		return n1+n2;
	}

	@Override
	public int somar(int n1, int n2, int n3) {
		// TODO Auto-generated method stub
		return n1+n2+n3;
	}

}
